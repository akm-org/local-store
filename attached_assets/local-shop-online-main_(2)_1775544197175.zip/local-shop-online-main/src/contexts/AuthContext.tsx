import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { User } from "@/lib/types";
import { getCurrentUser, setCurrentUser, getUsers, saveUsers, generateId, isAdminLoggedIn, setAdminLoggedIn } from "@/lib/store";

interface AuthContextType {
  user: User | null;
  adminMode: boolean;
  login: (email: string, password: string) => string | null;
  signup: (name: string, email: string, password: string, address: string, phone: string) => string | null;
  logout: () => void;
  adminLogin: (username: string, password: string) => boolean;
  adminLogout: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(getCurrentUser());
  const [adminMode, setAdminMode] = useState(isAdminLoggedIn());

  const login = (email: string, password: string): string | null => {
    const users = getUsers();
    const found = users.find((u) => u.email === email && u.password === password);
    if (!found) return "Invalid email or password";
    setUser(found);
    setCurrentUser(found);
    return null;
  };

  const signup = (name: string, email: string, password: string, address: string, phone: string): string | null => {
    const users = getUsers();
    if (users.find((u) => u.email === email)) return "Email already registered";
    const newUser: User = { user_id: generateId("U"), name, email, password, address, phone };
    users.push(newUser);
    saveUsers(users);
    setUser(newUser);
    setCurrentUser(newUser);
    return null;
  };

  const logout = () => {
    setUser(null);
    setCurrentUser(null);
  };

  const adminLogin = (username: string, password: string): boolean => {
    if (username === "admin" && password === "webdeveloper") {
      setAdminMode(true);
      setAdminLoggedIn(true);
      return true;
    }
    return false;
  };

  const adminLogout = () => {
    setAdminMode(false);
    setAdminLoggedIn(false);
  };

  return (
    <AuthContext.Provider value={{ user, adminMode, login, signup, logout, adminLogin, adminLogout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
