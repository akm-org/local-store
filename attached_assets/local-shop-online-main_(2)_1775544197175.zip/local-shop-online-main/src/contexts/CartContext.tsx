import React, { createContext, useContext, useState, ReactNode } from "react";
import { CartItem } from "@/lib/types";
import { getCart, saveCart, getProducts } from "@/lib/store";

interface CartContextType {
  items: CartItem[];
  addToCart: (productId: string) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, qty: number) => void;
  clearCart: () => void;
  totalItems: number;
  totalPrice: number;
}

const CartContext = createContext<CartContextType | null>(null);

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>(getCart());

  const persist = (newItems: CartItem[]) => {
    setItems(newItems);
    saveCart(newItems);
  };

  const addToCart = (productId: string) => {
    const current = [...items];
    const existing = current.find((i) => i.product_id === productId);
    if (existing) {
      existing.quantity += 1;
    } else {
      current.push({ product_id: productId, quantity: 1 });
    }
    persist(current);
  };

  const removeFromCart = (productId: string) => {
    persist(items.filter((i) => i.product_id !== productId));
  };

  const updateQuantity = (productId: string, qty: number) => {
    if (qty <= 0) return removeFromCart(productId);
    persist(items.map((i) => (i.product_id === productId ? { ...i, quantity: qty } : i)));
  };

  const clearCart = () => persist([]);

  const products = getProducts();
  const totalItems = items.reduce((s, i) => s + i.quantity, 0);
  const totalPrice = items.reduce((s, i) => {
    const p = products.find((pr) => pr.product_id === i.product_id);
    return s + (p ? p.price * i.quantity : 0);
  }, 0);

  return (
    <CartContext.Provider value={{ items, addToCart, removeFromCart, updateQuantity, clearCart, totalItems, totalPrice }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within CartProvider");
  return ctx;
}
