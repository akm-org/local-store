import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useCart } from "@/contexts/CartContext";
import { getOrders, saveOrders, getProducts, getAdminQR, generateId } from "@/lib/store";
import { Order } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";
import { CheckCircle } from "lucide-react";

export default function CheckoutPage() {
  const { user } = useAuth();
  const { items, totalPrice, clearCart } = useCart();
  const navigate = useNavigate();
  const [address, setAddress] = useState(user?.address || "");
  const [phone, setPhone] = useState(user?.phone || "");
  const [utr, setUtr] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [orderId, setOrderId] = useState("");
  const qr = getAdminQR();
  const products = getProducts();

  if (!user) { navigate("/login"); return null; }
  if (items.length === 0 && !submitted) { navigate("/cart"); return null; }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!address || !phone || !utr) { toast({ title: "Please fill all fields", variant: "destructive" }); return; }
    const oid = generateId("ORD");
    const order: Order = {
      order_id: oid, user_id: user.user_id,
      items: items.map((i) => { const p = products.find((pr) => pr.product_id === i.product_id); return { product_id: i.product_id, quantity: i.quantity, price: p?.price || 0 }; }),
      amount: totalPrice, address, phone, utr, status: "Pending", tracking_id: "", created_at: new Date().toISOString().split("T")[0],
    };
    const orders = getOrders(); orders.push(order); saveOrders(orders);
    clearCart(); setOrderId(oid); setSubmitted(true);
    toast({ title: "Order placed successfully!" });
  };

  if (submitted) {
    return (
      <div className="container py-20 text-center max-w-md mx-auto">
        <CheckCircle className="h-16 w-16 mx-auto text-success mb-4" />
        <h2 className="text-2xl font-bold mb-2">Order Confirmed!</h2>
        <p className="text-muted-foreground mb-4">Your order has been placed successfully.</p>
        <div className="glass-card rounded-xl p-6 text-left text-sm space-y-2">
          <p><span className="text-muted-foreground">Order ID:</span> <span className="font-mono font-bold">{orderId}</span></p>
          <p><span className="text-muted-foreground">Amount:</span> <span className="font-bold">₹{totalPrice}</span></p>
          <p><span className="text-muted-foreground">UTR:</span> <span className="font-mono">{utr}</span></p>
          <p><span className="text-muted-foreground">Status:</span> <span className="text-warning font-medium">Pending verification</span></p>
        </div>
        <Button className="mt-6 bg-primary hover:bg-primary/90" onClick={() => navigate("/orders")}>View My Orders</Button>
      </div>
    );
  }

  return (
    <div className="container py-8 max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold mb-6 glow-text">Checkout</h1>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="glass-card rounded-xl p-6 space-y-4">
          <h2 className="text-lg font-semibold">Delivery Details</h2>
          <div><Label>Delivery Address</Label><Input value={address} onChange={(e) => setAddress(e.target.value)} className="bg-secondary/50 border-border/50" required /></div>
          <div><Label>Phone Number</Label><Input value={phone} onChange={(e) => setPhone(e.target.value)} className="bg-secondary/50 border-border/50" required /></div>
        </div>
        <div className="glass-card rounded-xl p-6 space-y-4">
          <h2 className="text-lg font-semibold">Payment</h2>
          <p className="text-sm text-muted-foreground">Scan QR code, then enter your UTR number.</p>
          {qr ? (
            <div className="flex justify-center"><img src={qr} alt="Payment QR" className="h-48 w-48 rounded-lg border border-border/50" /></div>
          ) : (
            <div className="text-center py-8 glass rounded-lg text-sm text-muted-foreground">Admin has not uploaded a payment QR code yet.</div>
          )}
          <div><Label>UTR Number</Label><Input value={utr} onChange={(e) => setUtr(e.target.value)} className="bg-secondary/50 border-border/50" required /></div>
        </div>
        <div className="glass-card rounded-xl p-6">
          <h2 className="text-lg font-semibold mb-3">Order Summary</h2>
          <div className="space-y-2 text-sm">
            {items.map((item) => { const p = products.find((pr) => pr.product_id === item.product_id); return p ? (<div key={item.product_id} className="flex justify-between"><span className="text-muted-foreground">{p.name} × {item.quantity}</span><span>₹{p.price * item.quantity}</span></div>) : null; })}
          </div>
          <div className="border-t border-border/50 mt-3 pt-3 flex justify-between font-bold text-lg"><span>Total</span><span className="glow-text">₹{totalPrice}</span></div>
        </div>
        <Button type="submit" size="lg" className="w-full bg-primary hover:bg-primary/90 h-12">Place Order</Button>
      </form>
    </div>
  );
}
