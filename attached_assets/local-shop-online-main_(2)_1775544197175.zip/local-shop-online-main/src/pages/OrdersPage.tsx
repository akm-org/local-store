import React from "react";
import { useAuth } from "@/contexts/AuthContext";
import { getOrders, getProducts } from "@/lib/store";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Package } from "lucide-react";

const statusColor: Record<string, string> = {
  Pending: "bg-warning/15 text-warning border border-warning/20",
  Confirmed: "bg-info/15 text-info border border-info/20",
  Shipped: "bg-primary/15 text-primary border border-primary/20",
  Delivered: "bg-success/15 text-success border border-success/20",
};

export default function OrdersPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  if (!user) { navigate("/login"); return null; }

  const orders = getOrders().filter((o) => o.user_id === user.user_id).reverse();
  const products = getProducts();

  if (orders.length === 0) {
    return (
      <div className="container py-20 text-center">
        <Package className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
        <h2 className="text-2xl font-bold mb-2">No orders yet</h2>
        <p className="text-muted-foreground mb-6">Start shopping to see your orders here.</p>
        <Link to="/shop"><Button className="bg-primary hover:bg-primary/90">Shop Now</Button></Link>
      </div>
    );
  }

  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-6 glow-text">My Orders</h1>
      <div className="space-y-4">
        {orders.map((order) => (
          <div key={order.order_id} className="glass-card rounded-xl p-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
              <div>
                <p className="font-semibold font-mono">{order.order_id}</p>
                <p className="text-sm text-muted-foreground">{order.created_at}</p>
              </div>
              <span className={`px-3 py-1 rounded-full text-xs font-medium ${statusColor[order.status]}`}>{order.status}</span>
            </div>
            <div className="space-y-1.5 text-sm">
              {order.items.map((item) => { const p = products.find((pr) => pr.product_id === item.product_id); return (<div key={item.product_id} className="flex justify-between"><span className="text-muted-foreground">{p?.name || item.product_id} × {item.quantity}</span><span>₹{item.price * item.quantity}</span></div>); })}
            </div>
            <div className="border-t border-border/50 mt-3 pt-3 flex justify-between font-bold"><span>Total</span><span className="glow-text">₹{order.amount}</span></div>
            {order.tracking_id && <p className="text-sm mt-3 text-muted-foreground">Tracking: <span className="font-mono text-foreground">{order.tracking_id}</span></p>}
          </div>
        ))}
      </div>
    </div>
  );
}
