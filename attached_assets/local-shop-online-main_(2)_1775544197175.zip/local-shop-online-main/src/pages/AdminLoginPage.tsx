import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";
import { Shield } from "lucide-react";

export default function AdminLoginPage() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const { adminLogin } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminLogin(username, password)) { toast({ title: "Admin login successful!" }); navigate("/admin"); }
    else toast({ title: "Invalid credentials", variant: "destructive" });
  };

  return (
    <div className="container py-20 max-w-md mx-auto">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center h-16 w-16 rounded-full bg-primary/15 border border-primary/30 mb-4">
          <Shield className="h-8 w-8 text-primary" />
        </div>
        <h1 className="text-3xl font-bold glow-text">Admin Login</h1>
      </div>
      <form onSubmit={handleSubmit} className="space-y-4 glass-card rounded-xl p-8">
        <div><Label>Username</Label><Input value={username} onChange={(e) => setUsername(e.target.value)} className="bg-secondary/50 border-border/50" required /></div>
        <div><Label>Password</Label><Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="bg-secondary/50 border-border/50" required /></div>
        <Button type="submit" className="w-full bg-primary hover:bg-primary/90 h-11">Login as Admin</Button>
      </form>
    </div>
  );
}
