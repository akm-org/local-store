import React from "react";
import { Link } from "react-router-dom";
import { getProducts } from "@/lib/store";
import ProductCard from "@/components/ProductCard";
import { Button } from "@/components/ui/button";
import { ArrowRight, Star, Truck, ShieldCheck, RotateCcw, Zap, Sparkles } from "lucide-react";
import heroBanner from "@/assets/hero-banner.jpg";

export default function HomePage() {
  const products = getProducts();
  const featured = products.slice(0, 8);
  const trending = products.slice(20, 28);
  const newArrivals = products.slice(40, 44);

  const categories = [
    { name: "Dress", image: "https://images.unsplash.com/photo-1558171813-4c088753af8f?w=400&h=500&fit=crop", count: 20 },
    { name: "Lifestyle", image: "https://images.unsplash.com/photo-1545205597-3d9d02c29597?w=400&h=500&fit=crop", count: 20 },
    { name: "Essentials", image: "https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=500&fit=crop", count: 20 },
    { name: "Electronics", image: "https://images.unsplash.com/photo-1550009158-9ebf69173e03?w=400&h=500&fit=crop", count: 20 },
    { name: "Accessories", image: "https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=400&h=500&fit=crop", count: 20 },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative overflow-hidden min-h-[90vh] flex items-center">
        <img
          src={heroBanner}
          alt="LocalStore Fashion Collection"
          className="absolute inset-0 w-full h-full object-cover"
          width={1920}
          height={1080}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/80 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-background/40" />
        
        {/* Animated particles */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="particle particle-1" />
          <div className="particle particle-2" />
          <div className="particle particle-3" />
        </div>

        <div className="container relative z-10 py-16">
          <div className="max-w-2xl animate-page-in">
            <span className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.3em] text-primary mb-6 glass rounded-full px-4 py-2">
              <Sparkles className="h-3 w-3" /> New Collection 2026
            </span>
            <h1 className="text-6xl md:text-8xl font-black leading-[0.85] tracking-tighter mb-6">
              <span className="block text-foreground">DISCOVER</span>
              <span className="block glow-text">YOUR</span>
              <span className="block text-foreground">STYLE</span>
            </h1>
            <p className="text-lg text-muted-foreground mb-8 max-w-md leading-relaxed">
              100+ curated premium products across 5 categories. Quality you can trust at prices you'll love.
            </p>
            <div className="flex flex-wrap items-center gap-4">
              <Link to="/shop">
                <Button size="lg" className="bg-primary hover:bg-primary/90 text-lg px-10 h-14 font-bold rounded-full shadow-lg shadow-primary/30 hover:shadow-primary/50 transition-all hover:scale-105">
                  Shop Now <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link to="/shop?category=Dress">
                <Button size="lg" variant="outline" className="text-lg px-10 h-14 font-bold rounded-full border-foreground/20 hover:bg-foreground/10 hover:scale-105 transition-all">
                  Explore
                </Button>
              </Link>
            </div>

            <div className="mt-12 flex items-center gap-6">
              <div>
                <p className="text-4xl font-black glow-text">100+</p>
                <p className="text-xs text-muted-foreground uppercase tracking-wider">Products</p>
              </div>
              <div className="h-10 w-px bg-border/50" />
              <div>
                <p className="text-4xl font-black glow-text">10K+</p>
                <p className="text-xs text-muted-foreground uppercase tracking-wider">Customers</p>
              </div>
              <div className="h-10 w-px bg-border/50" />
              <div className="flex items-center gap-1">
                <div>
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-warning text-warning" />
                    ))}
                  </div>
                  <p className="text-xs text-muted-foreground uppercase tracking-wider mt-1">4.9 Rating</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Marquee */}
      <div className="bg-primary/10 border-y border-primary/20 py-3 overflow-hidden">
        <div className="animate-marquee whitespace-nowrap flex gap-12 text-primary font-bold text-sm uppercase tracking-widest">
          {Array(4).fill(null).map((_, i) => (
            <span key={i} className="flex items-center gap-12">
              <span>🔥 Free Delivery on ₹500+</span>
              <span>⚡ New Arrivals Weekly</span>
              <span>💎 Premium Quality</span>
              <span>🎁 Special Offers</span>
            </span>
          ))}
        </div>
      </div>

      {/* Features Strip */}
      <section className="py-12 border-b border-border/20">
        <div className="container grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { icon: Truck, label: "Free Shipping", desc: "Orders ₹500+" },
            { icon: ShieldCheck, label: "Secure Payment", desc: "QR code system" },
            { icon: RotateCcw, label: "Easy Returns", desc: "7-day policy" },
            { icon: Zap, label: "Fast Delivery", desc: "2-5 business days" },
          ].map((item, i) => (
            <div key={item.label} className="flex items-center gap-3 animate-slide-up" style={{ animationDelay: `${i * 0.1}s` }}>
              <div className="h-12 w-12 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center flex-shrink-0 border border-primary/10">
                <item.icon className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="font-bold text-sm">{item.label}</p>
                <p className="text-xs text-muted-foreground">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* New Arrivals - Big cards */}
      <section className="py-16">
        <div className="container">
          <div className="flex items-end justify-between mb-8">
            <div>
              <span className="text-xs font-bold uppercase tracking-[0.3em] text-primary">Just In</span>
              <h2 className="text-3xl md:text-5xl font-black tracking-tight mt-1">New Arrivals</h2>
            </div>
            <Link to="/shop" className="text-primary hover:underline text-sm font-semibold flex items-center gap-1">
              View All <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            {newArrivals.slice(0, 2).map((p, i) => (
              <Link key={p.product_id} to={`/product/${p.product_id}`} className="group relative rounded-3xl overflow-hidden aspect-[16/9] glass-card animate-slide-up" style={{ animationDelay: `${i * 0.15}s` }}>
                <img src={p.image} alt={p.name} className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" loading="lazy" />
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-6 md:p-8">
                  <span className="text-xs font-bold uppercase tracking-[0.2em] text-primary">{p.category}</span>
                  <h3 className="text-2xl md:text-3xl font-black mt-1">{p.name}</h3>
                  <p className="text-2xl font-black glow-text mt-2">₹{p.price}</p>
                  <Button className="mt-4 bg-primary hover:bg-primary/90 rounded-full font-bold hover:scale-105 transition-all">
                    Shop Now <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-16 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/[0.03] to-transparent" />
        <div className="container relative">
          <h2 className="text-3xl md:text-5xl font-black mb-2 tracking-tight">Shop by Category</h2>
          <p className="text-muted-foreground mb-8">Find exactly what you're looking for</p>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {categories.map((cat, i) => (
              <Link
                key={cat.name}
                to={`/shop?category=${cat.name}`}
                className="group relative aspect-[3/4] rounded-2xl overflow-hidden glass-card animate-slide-up"
                style={{ animationDelay: `${i * 0.1}s` }}
              >
                <img src={cat.image} alt={cat.name} className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" loading="lazy" />
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/30 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-5">
                  <p className="font-black text-xl">{cat.name}</p>
                  <p className="text-xs text-muted-foreground mt-1">{cat.count} Products</p>
                  <div className="mt-3 flex items-center gap-1 text-primary text-xs font-bold opacity-0 translate-y-2 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300">
                    Shop Now <ArrowRight className="h-3 w-3" />
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Trending */}
      <section className="py-16">
        <div className="container">
          <div className="flex items-end justify-between mb-8">
            <div>
              <span className="text-xs font-bold uppercase tracking-[0.3em] text-primary">🔥 Hot</span>
              <h2 className="text-3xl md:text-5xl font-black tracking-tight mt-1">Trending Now</h2>
            </div>
            <Link to="/shop" className="text-primary hover:underline text-sm font-semibold flex items-center gap-1">
              View All <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {trending.map((p) => (
              <ProductCard key={p.product_id} product={p} />
            ))}
          </div>
        </div>
      </section>

      {/* Featured */}
      <section className="py-16">
        <div className="container">
          <div className="flex items-end justify-between mb-8">
            <div>
              <span className="text-xs font-bold uppercase tracking-[0.3em] text-primary">⭐ Curated</span>
              <h2 className="text-3xl md:text-5xl font-black tracking-tight mt-1">Featured Products</h2>
            </div>
            <Link to="/shop" className="text-primary hover:underline text-sm font-semibold flex items-center gap-1">
              View All <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {featured.map((p) => (
              <ProductCard key={p.product_id} product={p} />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <section className="py-20">
        <div className="container">
          <div className="relative rounded-3xl overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-1483985988355-763728e1935b?w=1200&h=400&fit=crop"
              alt="Sale Banner"
              className="w-full h-64 md:h-80 object-cover"
              loading="lazy"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-background via-background/80 to-transparent" />
            <div className="absolute inset-0 flex items-center">
              <div className="container pl-8 md:pl-12">
                <span className="text-xs font-bold uppercase tracking-[0.3em] text-primary">Limited Time</span>
                <h2 className="text-4xl md:text-6xl font-black mt-2">
                  SAVE UP<br />TO <span className="glow-text">60%</span>
                </h2>
                <p className="text-muted-foreground mt-3 max-w-md">
                  Premium products at unbeatable prices. Don't miss out.
                </p>
                <Link to="/shop">
                  <Button size="lg" className="mt-6 bg-primary hover:bg-primary/90 rounded-full font-bold px-8 h-12 shadow-lg shadow-primary/30 hover:scale-105 transition-all">
                    Shop Now <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
