import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";

export default function SignupPage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [address, setAddress] = useState("");
  const [phone, setPhone] = useState("");
  const { signup } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const err = signup(name, email, password, address, phone);
    if (err) toast({ title: err, variant: "destructive" });
    else { toast({ title: "Account created!" }); navigate("/"); }
  };

  return (
    <div className="container py-12 max-w-md mx-auto">
      <h1 className="text-3xl font-bold text-center mb-8 glow-text">Sign Up</h1>
      <form onSubmit={handleSubmit} className="space-y-4 glass-card rounded-xl p-8">
        <div><Label>Full Name</Label><Input value={name} onChange={(e) => setName(e.target.value)} className="bg-secondary/50 border-border/50" required /></div>
        <div><Label>Email</Label><Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="bg-secondary/50 border-border/50" required /></div>
        <div><Label>Password</Label><Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="bg-secondary/50 border-border/50" required minLength={6} /></div>
        <div><Label>Address</Label><Input value={address} onChange={(e) => setAddress(e.target.value)} className="bg-secondary/50 border-border/50" required /></div>
        <div><Label>Phone</Label><Input value={phone} onChange={(e) => setPhone(e.target.value)} className="bg-secondary/50 border-border/50" required /></div>
        <Button type="submit" className="w-full bg-primary hover:bg-primary/90 h-11">Create Account</Button>
        <p className="text-sm text-center text-muted-foreground">
          Already have an account? <Link to="/login" className="text-primary hover:underline">Login</Link>
        </p>
      </form>
    </div>
  );
}
