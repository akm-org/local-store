import React from "react";
import { Link } from "react-router-dom";
import { getProducts } from "@/lib/store";
import { useWishlist } from "@/contexts/WishlistContext";
import ProductCard from "@/components/ProductCard";
import { Heart } from "lucide-react";

export default function WishlistPage() {
  const { wishlist } = useWishlist();
  const products = getProducts().filter((p) => wishlist.includes(p.product_id));

  return (
    <div className="container py-8 animate-page-in">
      <h1 className="text-3xl md:text-4xl font-black mb-2">My Wishlist</h1>
      <p className="text-muted-foreground mb-8">{products.length} saved items</p>

      {products.length === 0 ? (
        <div className="text-center py-20">
          <Heart className="h-16 w-16 mx-auto text-muted-foreground/30 mb-4" />
          <p className="text-muted-foreground mb-4">Your wishlist is empty</p>
          <Link to="/shop" className="text-primary font-semibold hover:underline">Browse Products</Link>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
          {products.map((p) => (
            <ProductCard key={p.product_id} product={p} />
          ))}
        </div>
      )}
    </div>
  );
}
