import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { getProducts, getOrders, getUsers } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Package, ShoppingCart, Users, BarChart3 } from "lucide-react";

export default function AdminDashboard() {
  const { adminMode } = useAuth();
  const navigate = useNavigate();
  if (!adminMode) { navigate("/admin/login"); return null; }

  const products = getProducts();
  const orders = getOrders();
  const users = getUsers();
  const totalRevenue = orders.filter(o => o.status !== "Pending").reduce((s, o) => s + o.amount, 0);
  const pendingOrders = orders.filter(o => o.status === "Pending").length;

  const stats = [
    { label: "Products", value: products.length, icon: Package, link: "/admin/products" },
    { label: "Orders", value: orders.length, icon: ShoppingCart, link: "/admin/orders" },
    { label: "Users", value: users.length, icon: Users, link: "#" },
    { label: "Revenue", value: `₹${totalRevenue}`, icon: BarChart3, link: "/admin/orders" },
  ];

  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-8 glow-text">Admin Dashboard</h1>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {stats.map((s) => (
          <Link key={s.label} to={s.link} className="glass-card rounded-xl p-6">
            <s.icon className="h-8 w-8 text-primary mb-3" />
            <p className="text-2xl font-black">{s.value}</p>
            <p className="text-sm text-muted-foreground">{s.label}</p>
          </Link>
        ))}
      </div>
      {pendingOrders > 0 && (
        <div className="glass rounded-xl p-4 mb-8 border-warning/30">
          <p className="font-semibold text-warning">⚠ {pendingOrders} orders pending verification</p>
          <Link to="/admin/orders"><Button size="sm" variant="outline" className="mt-2 border-warning/30 text-warning hover:bg-warning/10">Review Orders</Button></Link>
        </div>
      )}
      <div className="grid md:grid-cols-3 gap-4">
        <Link to="/admin/products"><Button variant="outline" className="w-full h-20 text-lg glass-card border-border/50 hover:border-primary/30">Manage Products</Button></Link>
        <Link to="/admin/orders"><Button variant="outline" className="w-full h-20 text-lg glass-card border-border/50 hover:border-primary/30">Manage Orders</Button></Link>
        <Link to="/admin/payment"><Button variant="outline" className="w-full h-20 text-lg glass-card border-border/50 hover:border-primary/30">Payment Settings</Button></Link>
      </div>
    </div>
  );
}
