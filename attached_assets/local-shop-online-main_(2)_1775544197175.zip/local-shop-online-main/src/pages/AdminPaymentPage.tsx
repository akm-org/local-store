import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { getAdminQR, setAdminQR } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";
import { Upload } from "lucide-react";

export default function AdminPaymentPage() {
  const { adminMode } = useAuth();
  const navigate = useNavigate();
  const [qr, setQr] = useState(getAdminQR());
  if (!adminMode) { navigate("/admin/login"); return null; }

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => { const d = ev.target?.result as string; setAdminQR(d); setQr(d); toast({ title: "QR code uploaded!" }); };
    reader.readAsDataURL(file);
  };

  return (
    <div className="container py-8 max-w-lg mx-auto">
      <h1 className="text-3xl font-bold mb-6 glow-text">Payment QR Code</h1>
      <div className="glass-card rounded-xl p-8 space-y-6">
        <p className="text-sm text-muted-foreground">Upload your UPI QR code. Customers will see this during checkout.</p>
        {qr ? (
          <div className="text-center">
            <img src={qr} alt="QR" className="h-64 w-64 mx-auto rounded-lg border border-border/50" />
            <Button variant="destructive" size="sm" className="mt-4" onClick={() => { setAdminQR(""); setQr(""); }}>Remove</Button>
          </div>
        ) : (
          <div className="border-2 border-dashed border-border/50 rounded-xl p-10 text-center">
            <Upload className="h-10 w-10 mx-auto text-muted-foreground mb-3" />
            <p className="text-muted-foreground">No QR code uploaded</p>
          </div>
        )}
        <div><Label>Upload QR Code</Label><Input type="file" accept="image/*" onChange={handleFileUpload} className="bg-secondary/50 border-border/50" /></div>
      </div>
    </div>
  );
}
