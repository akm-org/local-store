import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const err = login(email, password);
    if (err) toast({ title: err, variant: "destructive" });
    else { toast({ title: "Login successful!" }); navigate("/"); }
  };

  return (
    <div className="container py-20 max-w-md mx-auto">
      <h1 className="text-3xl font-bold text-center mb-8 glow-text">Login</h1>
      <form onSubmit={handleSubmit} className="space-y-4 glass-card rounded-xl p-8">
        <div><Label>Email</Label><Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="bg-secondary/50 border-border/50" required /></div>
        <div><Label>Password</Label><Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="bg-secondary/50 border-border/50" required /></div>
        <Button type="submit" className="w-full bg-primary hover:bg-primary/90 h-11">Login</Button>
        <p className="text-sm text-center text-muted-foreground">
          Don't have an account? <Link to="/signup" className="text-primary hover:underline">Sign up</Link>
        </p>
      </form>
    </div>
  );
}
