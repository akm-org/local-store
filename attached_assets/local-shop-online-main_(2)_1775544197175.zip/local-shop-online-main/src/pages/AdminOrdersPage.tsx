import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { getOrders, saveOrders, getProducts, getUsers } from "@/lib/store";
import { OrderStatus } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "@/hooks/use-toast";

const STATUSES: OrderStatus[] = ["Pending", "Confirmed", "Shipped", "Delivered"];
const statusColor: Record<string, string> = {
  Pending: "bg-warning/15 text-warning border border-warning/20",
  Confirmed: "bg-info/15 text-info border border-info/20",
  Shipped: "bg-primary/15 text-primary border border-primary/20",
  Delivered: "bg-success/15 text-success border border-success/20",
};

export default function AdminOrdersPage() {
  const { adminMode } = useAuth();
  const navigate = useNavigate();
  const [orders, setOrders] = useState(getOrders());
  const [trackingInputs, setTrackingInputs] = useState<Record<string, string>>({});
  const products = getProducts();
  const users = getUsers();

  if (!adminMode) { navigate("/admin/login"); return null; }

  const updateStatus = (orderId: string, status: OrderStatus) => {
    const updated = orders.map(o => o.order_id === orderId ? { ...o, status } : o);
    saveOrders(updated); setOrders(updated); toast({ title: `Order ${orderId} → ${status}` });
  };
  const sendTracking = (orderId: string) => {
    const tid = trackingInputs[orderId]; if (!tid) return;
    const updated = orders.map(o => o.order_id === orderId ? { ...o, tracking_id: tid } : o);
    saveOrders(updated); setOrders(updated); toast({ title: `Tracking ID sent` });
  };

  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-6 glow-text">Orders ({orders.length})</h1>
      <div className="space-y-4">
        {orders.slice().reverse().map(order => {
          const user = users.find(u => u.user_id === order.user_id);
          return (
            <div key={order.order_id} className="glass-card rounded-xl p-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
                <div><p className="font-semibold font-mono">{order.order_id}</p><p className="text-sm text-muted-foreground">{user?.name || order.user_id} · {order.created_at}</p></div>
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${statusColor[order.status]}`}>{order.status}</span>
              </div>
              <div className="text-sm space-y-1 mb-4">
                {order.items.map(item => { const p = products.find(pr => pr.product_id === item.product_id); return <p key={item.product_id} className="text-muted-foreground">{p?.name || item.product_id} × {item.quantity} — ₹{item.price * item.quantity}</p>; })}
                <p className="font-bold text-foreground">Total: <span className="glow-text">₹{order.amount}</span></p>
                <p className="text-muted-foreground">UTR: <span className="font-mono text-foreground">{order.utr}</span></p>
                {order.tracking_id && <p className="text-muted-foreground">Tracking: <span className="font-mono text-foreground">{order.tracking_id}</span></p>}
              </div>
              <div className="flex flex-wrap gap-2 items-center mb-3">
                {STATUSES.map(s => (<Button key={s} size="sm" onClick={() => updateStatus(order.order_id, s)} className={order.status === s ? "bg-primary text-primary-foreground" : "glass border-border/50 text-muted-foreground hover:text-foreground"}>{s}</Button>))}
              </div>
              <div className="flex gap-2">
                <Input placeholder="Tracking ID" value={trackingInputs[order.order_id] || ""} onChange={e => setTrackingInputs({ ...trackingInputs, [order.order_id]: e.target.value })} className="max-w-xs bg-secondary/50 border-border/50" />
                <Button variant="outline" size="sm" onClick={() => sendTracking(order.order_id)} className="border-border/50">Send</Button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
