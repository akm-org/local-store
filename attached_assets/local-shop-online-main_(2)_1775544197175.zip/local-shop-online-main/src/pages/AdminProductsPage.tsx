import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { getProducts, saveProducts, generateId } from "@/lib/store";
import { Product, Category } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";
import { Plus, Pencil, Trash2, X } from "lucide-react";

const CATEGORIES: Category[] = ["Dress", "Lifestyle", "Essentials", "Electronics", "Accessories"];

export default function AdminProductsPage() {
  const { adminMode } = useAuth();
  const navigate = useNavigate();
  const [products, setProducts] = useState(getProducts());
  const [editing, setEditing] = useState<Product | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: "", category: "Dress" as Category, price: "", stock: "", image: "", description: "" });

  if (!adminMode) { navigate("/admin/login"); return null; }

  const resetForm = () => { setForm({ name: "", category: "Dress", price: "", stock: "", image: "", description: "" }); setEditing(null); setShowForm(false); };

  const handleSave = () => {
    if (!form.name || !form.price) { toast({ title: "Fill required fields", variant: "destructive" }); return; }
    let updated: Product[];
    if (editing) {
      updated = products.map(p => p.product_id === editing.product_id ? { ...p, ...form, price: Number(form.price), stock: Number(form.stock) } : p);
      toast({ title: "Product updated!" });
    } else {
      const newP: Product = { product_id: generateId("P"), name: form.name, category: form.category, price: Number(form.price), stock: Number(form.stock) || 10, image: form.image || `https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=400&fit=crop`, description: form.description || `${form.name} - quality product` };
      updated = [...products, newP];
      toast({ title: "Product added!" });
    }
    saveProducts(updated); setProducts(updated); resetForm();
  };

  const handleDelete = (id: string) => { const updated = products.filter(p => p.product_id !== id); saveProducts(updated); setProducts(updated); toast({ title: "Product deleted!" }); };
  const startEdit = (p: Product) => { setForm({ name: p.name, category: p.category, price: String(p.price), stock: String(p.stock), image: p.image, description: p.description }); setEditing(p); setShowForm(true); };

  return (
    <div className="container py-8">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold glow-text">Products ({products.length})</h1>
        <Button onClick={() => { resetForm(); setShowForm(true); }} className="bg-primary hover:bg-primary/90"><Plus className="h-4 w-4 mr-1" />Add Product</Button>
      </div>
      {showForm && (
        <div className="glass-card rounded-xl p-6 mb-6 space-y-4">
          <div className="flex justify-between items-center"><h2 className="text-lg font-semibold">{editing ? "Edit Product" : "Add Product"}</h2><Button variant="ghost" size="icon" onClick={resetForm}><X className="h-4 w-4" /></Button></div>
          <div className="grid md:grid-cols-2 gap-4">
            <div><Label>Name *</Label><Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className="bg-secondary/50 border-border/50" /></div>
            <div><Label>Category</Label><select className="w-full rounded-lg glass px-3 py-2 text-sm bg-transparent" value={form.category} onChange={e => setForm({ ...form, category: e.target.value as Category })}>{CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}</select></div>
            <div><Label>Price (₹) *</Label><Input type="number" value={form.price} onChange={e => setForm({ ...form, price: e.target.value })} className="bg-secondary/50 border-border/50" /></div>
            <div><Label>Stock</Label><Input type="number" value={form.stock} onChange={e => setForm({ ...form, stock: e.target.value })} className="bg-secondary/50 border-border/50" /></div>
            <div className="md:col-span-2"><Label>Image URL</Label><Input value={form.image} onChange={e => setForm({ ...form, image: e.target.value })} className="bg-secondary/50 border-border/50" /></div>
            <div className="md:col-span-2"><Label>Description</Label><Input value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} className="bg-secondary/50 border-border/50" /></div>
          </div>
          <Button onClick={handleSave} className="bg-primary hover:bg-primary/90">{editing ? "Update" : "Add"} Product</Button>
        </div>
      )}
      <div className="glass-card rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="border-b border-border/50"><th className="text-left p-4 text-muted-foreground font-medium">Product</th><th className="text-left p-4 text-muted-foreground font-medium">Category</th><th className="text-left p-4 text-muted-foreground font-medium">Price</th><th className="text-left p-4 text-muted-foreground font-medium">Stock</th><th className="text-right p-4 text-muted-foreground font-medium">Actions</th></tr></thead>
            <tbody>{products.map(p => (<tr key={p.product_id} className="border-b border-border/30 hover:bg-secondary/20 transition-colors"><td className="p-4 flex items-center gap-3"><img src={p.image} alt={p.name} className="h-10 w-10 rounded-lg object-cover" /><span className="font-medium">{p.name}</span></td><td className="p-4 text-muted-foreground">{p.category}</td><td className="p-4">₹{p.price}</td><td className="p-4">{p.stock}</td><td className="p-4 text-right"><Button variant="ghost" size="icon" onClick={() => startEdit(p)}><Pencil className="h-4 w-4" /></Button><Button variant="ghost" size="icon" onClick={() => handleDelete(p.product_id)}><Trash2 className="h-4 w-4 text-destructive" /></Button></td></tr>))}</tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
