import React, { useState, useMemo } from "react";
import { useSearchParams } from "react-router-dom";
import { getProducts } from "@/lib/store";
import { Category } from "@/lib/types";
import ProductCard from "@/components/ProductCard";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, SlidersHorizontal } from "lucide-react";

const CATEGORIES: Category[] = ["Dress", "Lifestyle", "Essentials", "Electronics", "Accessories"];

export default function ShopPage() {
  const [searchParams] = useSearchParams();
  const [search, setSearch] = useState(searchParams.get("q") || "");
  const [category, setCategory] = useState<string>(searchParams.get("category") || "All");
  const [sort, setSort] = useState("default");

  const products = useMemo(() => {
    let list = getProducts();
    if (category !== "All") list = list.filter((p) => p.category === category);
    if (search) {
      const q = search.toLowerCase();
      list = list.filter((p) => p.name.toLowerCase().includes(q) || p.description.toLowerCase().includes(q));
    }
    if (sort === "low") list.sort((a, b) => a.price - b.price);
    if (sort === "high") list.sort((a, b) => b.price - a.price);
    return list;
  }, [search, category, sort]);

  return (
    <div className="container py-8 animate-page-in">
      <h1 className="text-3xl md:text-5xl font-black mb-2 tracking-tight">Shop</h1>
      <p className="text-muted-foreground mb-8">Explore our full collection of 100+ products</p>

      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search products..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-11 bg-secondary/50 border-border/50 h-11 rounded-full"
          />
        </div>
        <div className="flex gap-2 flex-wrap">
          {["All", ...CATEGORIES].map((c) => (
            <Button
              key={c}
              size="sm"
              onClick={() => setCategory(c)}
              className={`rounded-full transition-all ${category === c
                ? "bg-primary text-primary-foreground shadow-lg shadow-primary/30"
                : "bg-secondary/50 text-muted-foreground border border-border/50 hover:text-foreground hover:bg-secondary"}`}
            >
              {c}
            </Button>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <SlidersHorizontal className="h-4 w-4 text-muted-foreground" />
          <select
            className="rounded-full glass px-4 py-2 text-sm bg-transparent"
            value={sort}
            onChange={(e) => setSort(e.target.value)}
          >
            <option value="default">Sort by</option>
            <option value="low">Price: Low → High</option>
            <option value="high">Price: High → Low</option>
          </select>
        </div>
      </div>

      <p className="text-sm text-muted-foreground mb-6">{products.length} products found</p>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
        {products.map((p, i) => (
          <div key={p.product_id} style={{ animationDelay: `${Math.min(i * 0.05, 0.5)}s` }}>
            <ProductCard product={p} />
          </div>
        ))}
      </div>

      {products.length === 0 && (
        <div className="text-center py-20 text-muted-foreground">No products found.</div>
      )}
    </div>
  );
}
