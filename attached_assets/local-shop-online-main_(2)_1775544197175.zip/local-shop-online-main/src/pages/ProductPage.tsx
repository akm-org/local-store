import React from "react";
import { useParams, Link } from "react-router-dom";
import { getProducts } from "@/lib/store";
import { useCart } from "@/contexts/CartContext";
import { useWishlist } from "@/contexts/WishlistContext";
import { Button } from "@/components/ui/button";
import { ShoppingCart, ArrowLeft, Heart, Star, Truck, ShieldCheck } from "lucide-react";
import ProductCard from "@/components/ProductCard";

export default function ProductPage() {
  const { id } = useParams();
  const products = getProducts();
  const product = products.find((p) => p.product_id === id);
  const { addToCart } = useCart();
  const { toggleWishlist, isWishlisted } = useWishlist();

  if (!product) {
    return (
      <div className="container py-20 text-center animate-page-in">
        <p className="text-muted-foreground">Product not found.</p>
        <Link to="/shop"><Button variant="outline" className="mt-4 rounded-full">Back to Shop</Button></Link>
      </div>
    );
  }

  const wishlisted = isWishlisted(product.product_id);
  const related = products.filter((p) => p.category === product.category && p.product_id !== product.product_id).slice(0, 4);

  return (
    <div className="container py-8 animate-page-in">
      <Link to="/shop" className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground mb-6 transition-colors">
        <ArrowLeft className="h-4 w-4 mr-1" /> Back to Shop
      </Link>
      <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
        <div className="aspect-square rounded-3xl overflow-hidden glass-card">
          <img src={product.image} alt={product.name} className="h-full w-full object-cover" />
        </div>
        <div className="flex flex-col justify-center">
          <span className="text-xs font-bold glow-text uppercase tracking-[0.3em]">{product.category}</span>
          <h1 className="text-3xl md:text-4xl font-black mt-2 tracking-tight">{product.name}</h1>
          
          <div className="flex items-center gap-2 mt-3">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="h-4 w-4 fill-warning text-warning" />
            ))}
            <span className="text-sm text-muted-foreground ml-1">(128 reviews)</span>
          </div>

          <p className="text-4xl font-black glow-text mt-6">₹{product.price}</p>
          <p className="text-muted-foreground mt-4 leading-relaxed">{product.description}</p>
          <p className="text-sm mt-3 text-muted-foreground">Stock: <span className="text-foreground font-medium">{product.stock} available</span></p>

          <div className="flex gap-3 mt-8">
            <Button size="lg" className="bg-primary hover:bg-primary/90 h-12 px-8 rounded-full font-bold flex-1 md:flex-none shadow-lg shadow-primary/30 hover:scale-105 transition-all" onClick={() => addToCart(product.product_id)}>
              <ShoppingCart className="h-5 w-5 mr-2" /> Add to Cart
            </Button>
            <Button
              size="lg"
              variant="outline"
              className={`h-12 w-12 rounded-full p-0 transition-all ${wishlisted ? "border-red-500 text-red-500 bg-red-500/10" : "border-foreground/20"}`}
              onClick={() => toggleWishlist(product.product_id)}
            >
              <Heart className={`h-5 w-5 ${wishlisted ? "fill-current" : ""}`} />
            </Button>
          </div>

          <div className="grid grid-cols-2 gap-3 mt-8">
            <div className="flex items-center gap-2 glass rounded-xl p-3">
              <Truck className="h-4 w-4 text-primary" />
              <span className="text-xs text-muted-foreground">Free shipping ₹500+</span>
            </div>
            <div className="flex items-center gap-2 glass rounded-xl p-3">
              <ShieldCheck className="h-4 w-4 text-primary" />
              <span className="text-xs text-muted-foreground">Secure payment</span>
            </div>
          </div>
        </div>
      </div>

      {related.length > 0 && (
        <div className="mt-20">
          <h2 className="text-2xl font-black mb-6">Related Products</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {related.map((p) => (
              <ProductCard key={p.product_id} product={p} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
