import { Product, Category, User, Order } from "./types";

const categories: Category[] = ["Dress", "Lifestyle", "Essentials", "Electronics", "Accessories"];

const productNames: Record<Category, string[]> = {
  Dress: ["Cotton T-Shirt", "Denim Jacket", "Summer Dress", "Formal Shirt", "Linen Pants", "Silk Scarf", "Wool Sweater", "Polo Shirt", "Maxi Skirt", "Blazer", "Hoodie", "Cargo Shorts", "Floral Top", "Chino Pants", "Leather Belt Dress", "Kurta Set", "Track Pants", "Cardigan", "Mini Dress", "Trench Coat"],
  Lifestyle: ["Yoga Mat", "Water Bottle", "Fitness Band", "Journal Notebook", "Aromatherapy Candle", "Plant Pot", "Coffee Mug", "Desk Organizer", "Wall Clock", "Photo Frame", "Throw Pillow", "Essential Oil Set", "Bamboo Tray", "Meditation Cushion", "Reading Lamp", "Coaster Set", "Bookend", "Incense Holder", "Terrarium Kit", "Wind Chime"],
  Essentials: ["Hand Sanitizer", "Face Mask Pack", "Sunscreen SPF50", "Moisturizer", "Lip Balm", "Toothbrush Set", "Hair Comb", "Nail Clipper Kit", "Cotton Towel", "Soap Bar Set", "Shampoo Bottle", "Body Lotion", "Deodorant Stick", "Tissue Box", "First Aid Kit", "Sewing Kit", "Umbrella", "Laundry Bag", "Shoe Polish Kit", "Lint Roller"],
  Electronics: ["USB-C Cable", "Wireless Earbuds", "Phone Stand", "LED Strip Light", "Power Bank", "Mouse Pad", "Screen Protector", "USB Hub", "Webcam Cover", "Bluetooth Speaker", "Phone Case", "Cable Organizer", "Ring Light", "SD Card 32GB", "Keyboard Cleaner", "HDMI Cable", "Car Charger", "Laptop Sleeve", "Mini Fan", "Smart Plug"],
  Accessories: ["Silver Ring", "Beaded Bracelet", "Sunglasses", "Canvas Tote Bag", "Hair Clips Set", "Keychain", "Wallet", "Watch Strap", "Pendant Necklace", "Scrunchy Pack", "Belt", "Cufflinks", "Tie Pin", "Brooch", "Anklet", "Hat", "Gloves", "Ear Studs", "Chain Bracelet", "Badge Pin"],
};

// Curated Unsplash image IDs for each category
const categoryImages: Record<Category, string[]> = {
  Dress: [
    "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1601762603339-fd61e28b698a?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1434389677669-e08b4cda3a10?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1586363104862-3a5e2ab60d99?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1583496661160-fb5886a0aaaa?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1507680434567-5739c80be1ac?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1591195853828-11db59a44f6b?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1485968579580-b6d095142e6e?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1434389677669-e08b4cda3a10?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1612336307429-8a898d10e223?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=400&h=400&fit=crop",
  ],
  Lifestyle: [
    "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1576243345690-4e4b79b63288?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1517842645767-c639042777db?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1602607688066-d78eda1029d0?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1485955900006-10f4d324d411?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1542435503-956c469947f6?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1563861826100-9cb868fdbe1c?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1513542789411-b6a5d4f31634?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1616627451515-cbc80e5ece35?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1545205597-3d9d02c29597?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1507473885765-e6ed057ab6fe?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1558618666-fcd25c85f82e?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1600031326908-5d8d1b8a1e9e?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop",
  ],
  Essentials: [
    "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1588776813677-77aaf5595b83?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1556228720-195a672e8a03?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1586610476093-8fd0e8e17a7a?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1559589688-6ba6beafe000?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1585232351009-aa0e5c8b8ced?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1590439471364-192aa70c0b53?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1616594039964-ae9021a400a0?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1607006344380-b6775a0824a7?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1585232004423-244e0e6904e3?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1556228578-8c89e6adf883?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1596552183299-000ef779e88d?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1583947215259-38e31be8751f?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1603398938378-e54eab446dde?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1597484661973-ee6cd0b6482c?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1534088568595-a066f410bcda?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1558618666-fcd25c85f82e?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1585232004423-244e0e6904e3?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1563453392212-326f5e854473?w=400&h=400&fit=crop",
  ],
  Electronics: [
    "https://images.unsplash.com/photo-1558618666-fcd25c85f82e?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1590658268037-6bf12f032f55?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1583394838336-acd977736f90?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1558089687-f282ffcbc126?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1609091839311-d5365f9ff1c5?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1527814050087-3793815479db?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1601784551446-20c9e07cdbdb?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1625723044792-44de16ccb4e9?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1587145820266-a5951ee6f620?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1592899677977-9c10ca588bbd?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1625723044792-44de16ccb4e9?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1572569511254-d8f925fe2cbb?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1531525645387-7f14be1bdbbd?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1563206767-5b18f218e8de?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1558618666-fcd25c85f82e?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1570829460005-c840387bb1ca?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1587212593089-bfab28a91d59?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1593642632559-0c6d3fc62b89?w=400&h=400&fit=crop",
  ],
  Accessories: [
    "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1573408301185-9146fe634ad0?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1596944924616-7b38e7cfac36?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1609081219090-a6d81d3085bf?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1627123424574-724758594e93?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1524592094714-0f0654e20314?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1616530940355-351fabd9524b?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1590548784585-643d2b9f2e2b?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1598894000396-bc30e80c5cd0?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1611085583191-a3b181a88401?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1609081219090-a6d81d3085bf?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1521369909029-2afed882baee?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1531310197839-ccf54634509e?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1594534475808-b18fc33b045e?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1573408301185-9146fe634ad0?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1608042314453-ae338d80c427?w=400&h=400&fit=crop",
  ],
};

const descriptions: Record<Category, string> = {
  Dress: "Premium quality fabric with comfortable fit. Perfect for everyday wear.",
  Lifestyle: "Enhance your daily life with this carefully crafted lifestyle product.",
  Essentials: "A daily essential you can't go without. Quality guaranteed.",
  Electronics: "High-quality electronics accessory for your tech needs.",
  Accessories: "Stylish accessory to complement your look.",
};

function generateProducts(): Product[] {
  const products: Product[] = [];
  let id = 1;
  for (const category of categories) {
    const names = productNames[category];
    const images = categoryImages[category];
    for (let i = 0; i < names.length; i++) {
      const name = names[i];
      const price = Math.floor(Math.random() * 401) + 100;
      const stock = Math.floor(Math.random() * 50) + 5;
      products.push({
        product_id: `P${String(id).padStart(3, "0")}`,
        name,
        category,
        price,
        stock,
        image: images[i],
        description: `${descriptions[category]} ${name} - available in multiple variants. Made with care and attention to detail.`,
      });
      id++;
    }
  }
  return products;
}

function generateSampleUsers(): User[] {
  return [
    { user_id: "U001", name: "Rahul Sharma", email: "rahul@example.com", password: "password123", address: "123 MG Road, Mumbai", phone: "9876543210" },
    { user_id: "U002", name: "Priya Patel", email: "priya@example.com", password: "password123", address: "456 Anna Nagar, Chennai", phone: "9876543211" },
    { user_id: "U003", name: "Amit Kumar", email: "amit@example.com", password: "password123", address: "789 Sector 15, Noida", phone: "9876543212" },
  ];
}

function generateSampleOrders(): Order[] {
  return [
    {
      order_id: "ORD001", user_id: "U001", items: [{ product_id: "P001", quantity: 1, price: 350 }],
      amount: 350, address: "123 MG Road, Mumbai", phone: "9876543210",
      utr: "UTR123456789", status: "Delivered", tracking_id: "TRK001ABC", created_at: "2026-03-15",
    },
    {
      order_id: "ORD002", user_id: "U002", items: [{ product_id: "P025", quantity: 2, price: 200 }],
      amount: 400, address: "456 Anna Nagar, Chennai", phone: "9876543211",
      utr: "UTR987654321", status: "Shipped", tracking_id: "TRK002DEF", created_at: "2026-04-01",
    },
  ];
}

export function initializeData() {
  // Always refresh products to get new images
  localStorage.setItem("ls_products", JSON.stringify(generateProducts()));
  if (!localStorage.getItem("ls_users")) {
    localStorage.setItem("ls_users", JSON.stringify(generateSampleUsers()));
  }
  if (!localStorage.getItem("ls_orders")) {
    localStorage.setItem("ls_orders", JSON.stringify(generateSampleOrders()));
  }
  if (!localStorage.getItem("ls_admin_qr")) {
    localStorage.setItem("ls_admin_qr", "");
  }
}
