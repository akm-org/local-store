export interface User {
  user_id: string;
  name: string;
  email: string;
  password: string;
  address: string;
  phone: string;
}

export interface Product {
  product_id: string;
  name: string;
  category: Category;
  price: number;
  stock: number;
  image: string;
  description: string;
}

export type Category = "Dress" | "Lifestyle" | "Essentials" | "Electronics" | "Accessories";

export type OrderStatus = "Pending" | "Confirmed" | "Shipped" | "Delivered";

export interface Order {
  order_id: string;
  user_id: string;
  items: { product_id: string; quantity: number; price: number }[];
  amount: number;
  address: string;
  phone: string;
  utr: string;
  status: OrderStatus;
  tracking_id: string;
  created_at: string;
}

export interface CartItem {
  product_id: string;
  quantity: number;
}
