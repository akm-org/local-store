import { User, Product, Order, CartItem } from "./types";

// Products
export function getProducts(): Product[] {
  return JSON.parse(localStorage.getItem("ls_products") || "[]");
}
export function saveProducts(products: Product[]) {
  localStorage.setItem("ls_products", JSON.stringify(products));
}

// Users
export function getUsers(): User[] {
  return JSON.parse(localStorage.getItem("ls_users") || "[]");
}
export function saveUsers(users: User[]) {
  localStorage.setItem("ls_users", JSON.stringify(users));
}

// Orders
export function getOrders(): Order[] {
  return JSON.parse(localStorage.getItem("ls_orders") || "[]");
}
export function saveOrders(orders: Order[]) {
  localStorage.setItem("ls_orders", JSON.stringify(orders));
}

// Cart
export function getCart(): CartItem[] {
  return JSON.parse(localStorage.getItem("ls_cart") || "[]");
}
export function saveCart(cart: CartItem[]) {
  localStorage.setItem("ls_cart", JSON.stringify(cart));
}

// Auth
export function getCurrentUser(): User | null {
  const u = localStorage.getItem("ls_current_user");
  return u ? JSON.parse(u) : null;
}
export function setCurrentUser(user: User | null) {
  if (user) localStorage.setItem("ls_current_user", JSON.stringify(user));
  else localStorage.removeItem("ls_current_user");
}

export function isAdminLoggedIn(): boolean {
  return localStorage.getItem("ls_admin_logged_in") === "true";
}
export function setAdminLoggedIn(v: boolean) {
  localStorage.setItem("ls_admin_logged_in", String(v));
}

// QR
export function getAdminQR(): string {
  return localStorage.getItem("ls_admin_qr") || "";
}
export function setAdminQR(qr: string) {
  localStorage.setItem("ls_admin_qr", qr);
}

// Generate unique IDs
export function generateId(prefix: string): string {
  return `${prefix}${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`.toUpperCase();
}
