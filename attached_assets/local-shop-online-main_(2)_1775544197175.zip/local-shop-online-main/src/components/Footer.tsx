import React from "react";
import { Link } from "react-router-dom";
import { Instagram, Twitter, Facebook, Mail } from "lucide-react";

export default function Footer() {
  return (
    <footer className="border-t border-border/30 mt-auto relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-t from-primary/[0.03] to-transparent pointer-events-none" />
      <div className="container relative py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <p className="font-black text-2xl glow-text mb-3 tracking-tighter">LOCALSTORE</p>
            <p className="text-sm text-muted-foreground leading-relaxed">Your one-stop shop for quality products at affordable prices.</p>
            <div className="flex gap-3 mt-4">
              {[Instagram, Twitter, Facebook, Mail].map((Icon, i) => (
                <a key={i} href="#" className="h-9 w-9 rounded-full glass flex items-center justify-center text-muted-foreground hover:text-primary transition-colors">
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>
          <div>
            <h3 className="font-bold mb-4 text-sm uppercase tracking-wider">Categories</h3>
            <ul className="text-sm text-muted-foreground space-y-2">
              {["Dress", "Lifestyle", "Essentials", "Electronics", "Accessories"].map((c) => (
                <li key={c}><Link to={`/shop?category=${c}`} className="hover:text-foreground transition-colors">{c}</Link></li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="font-bold mb-4 text-sm uppercase tracking-wider">Quick Links</h3>
            <ul className="text-sm text-muted-foreground space-y-2">
              <li><Link to="/shop" className="hover:text-foreground transition-colors">Shop</Link></li>
              <li><Link to="/cart" className="hover:text-foreground transition-colors">Cart</Link></li>
              <li><Link to="/wishlist" className="hover:text-foreground transition-colors">Wishlist</Link></li>
              <li><Link to="/orders" className="hover:text-foreground transition-colors">My Orders</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="font-bold mb-4 text-sm uppercase tracking-wider">Contact</h3>
            <p className="text-sm text-muted-foreground">Email: adwaithkm896@gmail.com</p>
            <p className="text-sm text-muted-foreground mt-1">Phone: +91 9946583184</p>
            <p className="text-sm text-muted-foreground mt-1">Telegram: @akmkali</p>
          </div>
        </div>
        <div className="border-t border-border/30 mt-8 pt-6 text-center text-sm text-muted-foreground">
          © 2026 LocalStore. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
