import React, { useState } from "react";
import { Link } from "react-router-dom";
import { ShoppingCart, User, LogOut, Search, Menu, X, Heart, Package } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useCart } from "@/contexts/CartContext";
import { useWishlist } from "@/contexts/WishlistContext";
import { Button } from "@/components/ui/button";

const NAV_LINKS = [
  { to: "/shop", label: "Shop" },
  { to: "/shop?category=Dress", label: "Dress" },
  { to: "/shop?category=Lifestyle", label: "Lifestyle" },
  { to: "/shop?category=Electronics", label: "Electronics" },
  { to: "/shop?category=Accessories", label: "Accessories" },
  { to: "/shop?category=Essentials", label: "Essentials" },
];

export default function Navbar() {
  const { user, adminMode, logout, adminLogout } = useAuth();
  const { totalItems } = useCart();
  const { wishlistCount } = useWishlist();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-50 glass-strong">
      <div className="container flex h-16 items-center justify-between">
        <Link to="/" className="flex items-center gap-2 font-black text-2xl tracking-tighter">
          <span className="glow-text">LOCALSTORE</span>
        </Link>

        <div className="hidden lg:flex items-center gap-6">
          {NAV_LINKS.map((link) => (
            <Link
              key={link.label}
              to={link.to}
              className="text-muted-foreground hover:text-foreground transition-colors uppercase tracking-wider text-xs font-semibold relative group"
            >
              {link.label}
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary transition-all duration-300 group-hover:w-full" />
            </Link>
          ))}
        </div>

        <div className="flex items-center gap-1">
          <Link to="/shop">
            <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
              <Search className="h-5 w-5" />
            </Button>
          </Link>

          <Link to="/wishlist" className="relative">
            <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
              <Heart className="h-5 w-5" />
              {wishlistCount > 0 && (
                <span className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-red-500 text-white text-[10px] flex items-center justify-center font-bold">
                  {wishlistCount}
                </span>
              )}
            </Button>
          </Link>

          {adminMode ? (
            <Button variant="ghost" size="sm" onClick={adminLogout} className="text-muted-foreground">
              <LogOut className="h-4 w-4 mr-1" />Logout
            </Button>
          ) : (
            <>
              <Link to="/cart" className="relative">
                <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
                  <ShoppingCart className="h-5 w-5" />
                  {totalItems > 0 && (
                    <span className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center font-bold animate-pulse">
                      {totalItems}
                    </span>
                  )}
                </Button>
              </Link>
              {user ? (
                <>
                  <Link to="/orders">
                    <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground hidden sm:inline-flex">
                      <Package className="h-5 w-5" />
                    </Button>
                  </Link>
                  <Link to="/orders">
                    <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground hidden md:inline-flex">
                      <User className="h-4 w-4 mr-1" />{user.name.split(" ")[0]}
                    </Button>
                  </Link>
                  <Button variant="ghost" size="icon" onClick={logout} className="text-muted-foreground">
                    <LogOut className="h-4 w-4" />
                  </Button>
                </>
              ) : (
                <div className="hidden sm:flex items-center gap-2">
                  <Link to="/login">
                    <Button size="sm" className="bg-primary hover:bg-primary/90 font-semibold rounded-full px-5">Login</Button>
                  </Link>
                  <Link to="/signup">
                    <Button size="sm" variant="outline" className="border-foreground/20 hover:bg-foreground/10 font-semibold rounded-full px-5">Sign Up</Button>
                  </Link>
                </div>
              )}
            </>
          )}

          <Button variant="ghost" size="icon" className="lg:hidden text-muted-foreground" onClick={() => setMobileOpen(!mobileOpen)}>
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
      </div>

      {mobileOpen && (
        <div className="lg:hidden glass-strong border-t border-border/30 animate-slide-down">
          <div className="container py-4 flex flex-col gap-3">
            {NAV_LINKS.map((link) => (
              <Link
                key={link.label}
                to={link.to}
                onClick={() => setMobileOpen(false)}
                className="text-muted-foreground hover:text-foreground transition-colors uppercase tracking-wider text-sm font-semibold py-2"
              >
                {link.label}
              </Link>
            ))}
            <Link to="/wishlist" onClick={() => setMobileOpen(false)} className="text-muted-foreground hover:text-foreground transition-colors uppercase tracking-wider text-sm font-semibold py-2">
              Wishlist ({wishlistCount})
            </Link>
            {!user && (
              <div className="flex gap-2 pt-2 border-t border-border/30">
                <Link to="/login" onClick={() => setMobileOpen(false)} className="flex-1">
                  <Button className="w-full bg-primary hover:bg-primary/90 rounded-full">Login</Button>
                </Link>
                <Link to="/signup" onClick={() => setMobileOpen(false)} className="flex-1">
                  <Button variant="outline" className="w-full border-foreground/20 rounded-full">Sign Up</Button>
                </Link>
              </div>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
