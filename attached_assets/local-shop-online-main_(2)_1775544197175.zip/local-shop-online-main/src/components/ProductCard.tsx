import React from "react";
import { Link } from "react-router-dom";
import { Product } from "@/lib/types";
import { useCart } from "@/contexts/CartContext";
import { useWishlist } from "@/contexts/WishlistContext";
import { Button } from "@/components/ui/button";
import { ShoppingCart, Eye, Heart } from "lucide-react";

export default function ProductCard({ product }: { product: Product }) {
  const { addToCart } = useCart();
  const { toggleWishlist, isWishlisted } = useWishlist();
  const wishlisted = isWishlisted(product.product_id);

  return (
    <div className="group glass-card rounded-2xl overflow-hidden animate-slide-up">
      <Link to={`/product/${product.product_id}`}>
        <div className="aspect-square overflow-hidden relative">
          <img
            src={product.image}
            alt={product.name}
            className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
            loading="lazy"
          />
          {product.stock < 10 && (
            <span className="absolute top-3 left-3 badge-stock text-xs font-bold px-2.5 py-1 rounded-full text-foreground">
              Only {product.stock} left
            </span>
          )}
          {/* Wishlist heart */}
          <button
            onClick={(e) => { e.preventDefault(); e.stopPropagation(); toggleWishlist(product.product_id); }}
            className={`absolute top-3 right-3 h-9 w-9 rounded-full flex items-center justify-center transition-all duration-300 backdrop-blur-md ${
              wishlisted
                ? "bg-red-500/90 text-white scale-110"
                : "bg-background/40 text-foreground/60 hover:bg-background/60 hover:text-red-400"
            }`}
          >
            <Heart className={`h-4 w-4 ${wishlisted ? "fill-current" : ""}`} />
          </button>
          {/* Hover overlay */}
          <div className="absolute inset-0 bg-background/60 opacity-0 group-hover:opacity-100 transition-all duration-300 flex items-center justify-center gap-3">
            <Button
              size="sm"
              className="bg-primary hover:bg-primary/90 rounded-full h-10 w-10 p-0 shadow-lg shadow-primary/30"
              onClick={(e) => { e.preventDefault(); addToCart(product.product_id); }}
            >
              <ShoppingCart className="h-4 w-4" />
            </Button>
            <Link to={`/product/${product.product_id}`} onClick={(e) => e.stopPropagation()}>
              <Button size="sm" variant="outline" className="rounded-full h-10 w-10 p-0 border-foreground/30 hover:bg-foreground/10">
                <Eye className="h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </Link>
      <div className="p-4">
        <span className="text-[10px] font-bold glow-text uppercase tracking-[0.2em]">{product.category}</span>
        <Link to={`/product/${product.product_id}`}>
          <h3 className="font-semibold mt-1 line-clamp-1 text-foreground/90 group-hover:text-foreground transition-colors text-sm">{product.name}</h3>
        </Link>
        <div className="flex items-center justify-between mt-3">
          <span className="text-lg font-black text-foreground">₹{product.price}</span>
          <Button
            size="sm"
            onClick={() => addToCart(product.product_id)}
            className="bg-primary/20 text-primary border border-primary/30 hover:bg-primary/40 transition-all rounded-full text-xs px-3"
          >
            <ShoppingCart className="h-3 w-3 mr-1" />Add
          </Button>
        </div>
      </div>
    </div>
  );
}
